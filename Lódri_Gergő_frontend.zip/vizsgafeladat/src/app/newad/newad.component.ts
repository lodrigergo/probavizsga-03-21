import { Component, OnInit } from '@angular/core';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface Kategoria {
  id: number;
  nev: string;
}

interface UjIngatlan {
  kategoriaId: number;
  leiras: string;
  hirdetesDatuma: string;
  tehermentes: boolean;
  kepUrl: string;
}

@Component({
  selector: 'app-newad',
  imports: [FormsModule, CommonModule],
  templateUrl: './newad.component.html',
  styleUrl: './newad.component.css'
})


export class NewadComponent implements OnInit{

  kategoriak: Kategoria[] = [];
  ujIngatlan: UjIngatlan = {
    kategoriaId: 0,
    leiras: '',
    hirdetesDatuma: '',
    tehermentes: true,
    kepUrl: ''
  };
  errorMessage: string = '';

  private readonly API_KATEGORIA_URL = 'http://localhost:5000/api/kategoriak';
  private readonly API_UJINGATLAN_URL = 'http://localhost:5000/api/ujingatlan';

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.http.get<Kategoria[]>(this.API_KATEGORIA_URL).subscribe(data => {
      this.kategoriak = data;
      this.ujIngatlan.hirdetesDatuma = this.getCurrentDate();
    });
  }

  getCurrentDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  submitAd(): void {
    this.http.post(this.API_UJINGATLAN_URL, this.ujIngatlan).subscribe({
      next: () => {
        this.router.navigate(['/offers']);
      },
      error: (error) => {
        this.errorMessage = error.message;
      }
    });
  }

  navigateToNewAd(): void {
    this.router.navigate(['/newad']);
  }
}

