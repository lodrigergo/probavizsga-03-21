import { Routes } from '@angular/router';
import { OpenpageComponent } from './openpage/openpage.component';
import { OffersComponent } from './offers/offers.component';
import { NewadComponent } from './newad/newad.component';

export const routes: Routes = [
    {path: '', redirectTo:'/openPage', pathMatch:'full'},
    {path:'openPage', component: OpenpageComponent},
    {path:'offers', component: OffersComponent},
    {path:'newad', component: NewadComponent},
];
