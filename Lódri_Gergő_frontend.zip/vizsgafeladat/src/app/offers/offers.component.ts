import { Component, OnInit } from '@angular/core';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';



interface Ingatlan {
  id: number;
  kategoriaId: number;
  kategoriaNev: string;
  leiras: string;
  hirdetesDatuma: string;
  tehermentes: boolean;
  kepUrl: string;
}

@Component({
  selector: 'app-offers',
  imports: [CommonModule],
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css'],
  /* providers: [provideHttpClient()], */
})

export class OffersComponent implements OnInit {
  ingatlanok: Ingatlan[] = [];
  private readonly API_URL = 'http://localhost:5000/api/ingatlan';

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.http.get<Ingatlan[]>(this.API_URL).subscribe(data => {
      this.ingatlanok = data;
    });
  }

  navigateToOffers(): void {
    this.router.navigate(['/offers']);
  }
}



