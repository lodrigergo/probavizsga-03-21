import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-openpage',
  imports: [OpenpageComponent],
  templateUrl: './openpage.component.html',
  styleUrl: './openpage.component.css'
})
export class OpenpageComponent {

  constructor(
    private router: Router
  ){}
    
    
  
  navigateToOffers(): void {
    this.router.navigate(['/offers']);
  }

  navigateToNewAd(): void {
    this.router.navigate(['/newad']);
  }
}
